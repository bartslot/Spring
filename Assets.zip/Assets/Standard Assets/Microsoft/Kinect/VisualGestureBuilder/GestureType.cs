using RootSystem = System;
using System.Linq;
using System.Collections.Generic;
namespace Microsoft.Kinect.VisualGestureBuilder
{
    //
    // Microsoft.Kinect.VisualGestureBuilder.GestureType
    //
    public enum GestureType : int
    {
        None                                     =0,
        Discrete                                 =1,
        Continuous                               =2,
    }

}
