using RootSystem = System;
using System.Linq;
using System.Collections.Generic;
namespace Windows.Kinect
{
    //
    // Windows.Kinect.Appearance
    //
    public enum Appearance : int
    {
        WearingGlasses                           =0,
    }

}
